package classes;

import java.util.Random;

public class Guard {
	private int x;
	private int y;
	private boolean arrested;

	public Guard(int x, int y) {
		this.x = x;
		this.y = y;
		this.arrested = false;
	}

	public void mover(String[][] tablero) {
		Random random = new Random();

		// Generamos un número aleatorio entre 0 y 3 para determinar a qué casilla
		// adyacente nos vamos a mover
		int direccion = random.nextInt(4);
		if (direccion == 0 && x > 0 && tablero[x - 1][y].equals("X")) {
			// Nos movemos hacia la izquierda
			x--;
		} else if (direccion == 1 && x < 9 && tablero[x + 1][y].equals("X")) {
			// Nos movemos hacia la derecha
			x++;
		} else if (direccion == 2 && y > 0 && tablero[x][y - 1].equals("X")) {
			// Nos movemos hacia arriba
			y--;
		} else if (direccion == 3 && y < 9 && tablero[x][y + 1].equals("X")) {
			// Nos movemos hacia abajo
			y++;
		}
	}

	public boolean isArrestado() {
		return arrested;
	}

	public void setArrestado(boolean arrestado) {
		this.arrested = arrestado;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
}
