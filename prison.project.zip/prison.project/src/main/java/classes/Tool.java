package classes;

import java.util.ArrayList;
import java.util.List;

public class Tool {
	private String type;
	private List<Position> positions;

	public Tool(String type) {
		this.type = type;
		this.positions = new ArrayList<>();
	}

	public String getType() {
		return type;
	}

	public void addPosition(int x, int y) {
		Position posicion = new Position(x, y);
		positions.add(posicion);
	}
}

class Position {
	private int x;
	private int y;

	public Position(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
