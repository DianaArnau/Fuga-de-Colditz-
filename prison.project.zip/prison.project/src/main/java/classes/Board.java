package classes;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import java.util.Scanner;
//TODO AÑADIR MOVIMIENTO JUGADOR. ARREGLADO EL INDEX PERO A VECES UNA HERRAMIENTA NO SALE Y TENGO QUE CONTROLAR QUE SIEMPRE SALGAN. 
public class Board implements KeyListener {
	Random r = new Random();
	String[][] board = new String[10][10];
	int x = r.nextInt(10);
	int y = r.nextInt(10);
	private static boolean[][] ocupado = new boolean[10][10];

	// TODO ARREGLAR 3 UNIFORMES EN CASILLA, ARREGLAR PEDIR MOVIMIENTO CON SYSOUT AL
	// JUGADOR.
	public Board() {
		// Creación de las herramientas
		Tool player = new Tool("p");
		Tool pliers = new Tool("A");
		Tool uniform = new Tool("U");
		Tool passport = new Tool("P");

		// Generación de posiciones aleatorias para las herramientas
		int x = r.nextInt(10);
		int y = r.nextInt(10);
		// Verificación de que la casilla esté vacía y que no haya herramientas
		// adyacentes
		if (!ocupado[x][y] && !hayHerramientasAdyacentes(x, y)) {
			// Ocupación de la casilla y marcado como ocupada
			board[x][y] = player.getType();
			ocupado[x][y] = true;
			player.addPosition(x, y);

		}
		// Generación de nuevas posiciones aleatorias para la otra herramienta
		x = r.nextInt(10);
		y = r.nextInt(10);
		// Verificación de que la casilla esté vacía y que no haya herramientas
		// adyacentes
		if (!ocupado[x][y] && !hayHerramientasAdyacentes(x, y)) {
			// Ocupación de la casilla y marcado como ocupada
			// le sumo mas uno a los alicates, porque lo pide el ejercicio
			// le he dado desde mi posicion actual que me recorra a la derecha( con x + 1 )
			// y luego cambio el valor de la Y por la i del for
			// y luego cambio el valor de la Y por la i del for
			for (int i = y; i <= y + 1; i++) {
				if (i < 10) { // Verificación para evitar "index out of bounds"
					board[x][i] = pliers.getType();
					ocupado[x][i] = true;
					pliers.addPosition(x, i);
					// TODO ME falta comprobar luego si las casillas de los lados o de arriba (x-1 ,
					// y-1 etc) y llamar a la funcion piedraPapel
				}
			}
			// Generación de nuevas posiciones aleatorias para la otra herramienta
			x = r.nextInt(10);
			y = r.nextInt(10);
			// Verificación de que la casilla esté vacía y que no haya herramientas
			// adyacentes
			if (!ocupado[x][y] && !hayHerramientasAdyacentes(x, y)) {
				// Ocupación de la casilla y marcado como ocupada
				board[x][y] = uniform.getType();
				ocupado[x][y] = true;
				uniform.addPosition(x, y);
				// TODO ERROR ARREGLAR INDEX OUT OF BOUNDS
				for (int i = y; i <= y + 2; i++) {
					if (i < 10) {
						board[x][i] = uniform.getType();
						ocupado[x][i] = true;
						uniform.addPosition(x, i);
						// TODO ME falta comprobar luego si las casillas de los lados o de arriba (x-1 ,
						// y-1 etc) y llamar a la funcion piedraPapel
					}
				}
			}

			// Generación de nuevas posiciones aleatorias para la otra herramienta
			x = r.nextInt(10);
			y = r.nextInt(10);
			// Verificación de que la casilla esté vacía y que no haya herramientas
			// adyacentes
			if (!ocupado[x][y] && !hayHerramientasAdyacentes(x, y)) {
				// Ocupación de la casilla y marcado como ocupada
				board[x][y] = passport.getType();
				ocupado[x][y] = true;
				passport.addPosition(x, y);
			}
		}
	}

	public static void moverJugador(int x, int y, String[][] board, String movimiento) {

		switch (movimiento) {
		case "arriba":
			if (comprobarMovimiento(x, y + 1, board))
				y++;
			if (hayHerramientasAdyacentes(x, y)) {
				jugarPiedraPapelTijeras();
			}
			break;
		case "abajo":
			if (comprobarMovimiento(x, y - 1, board))
				y--;
			if (hayHerramientasAdyacentes(x, y)) {
				jugarPiedraPapelTijeras();
			}
			break;
		case "derecha":
			if (comprobarMovimiento(x + 1, y, board))
				x++;
			if (hayHerramientasAdyacentes(x, y)) {
				jugarPiedraPapelTijeras();
			}
			break;
		case "izquierda":
			if (comprobarMovimiento(x - 1, y, board))
				x--;
			if (hayHerramientasAdyacentes(x, y)) {
				jugarPiedraPapelTijeras();
			}
			break;
		}
	}

	private static boolean comprobarMovimiento(int x, int y, String[][] board) {
		// Si pasa esto es que esta fuera de la matriz . El 0 es poruqe es la primera
		// posicion, lo cual, si es menor que es 0 esta fuera de la matriz. En el 0 no
		// es menor o igual, porque si es 0 esta dentro de la matriz.
		if (x >= board.length || y >= board.length || x < 0 || y < 0) {
			return false;
		}

		return true;
	}

	private static boolean hayHerramientasAdyacentes(int x, int y) {
		// Comprobamos si hay alguna herramienta adyacente en las casillas del entorno
		if (x > 0 && ocupado[x - 1][y]) {

			return true;
		}
		if (x < 9 && ocupado[x + 1][y]) {
			return true;
		}
		if (y > 0 && ocupado[x][y - 1]) {
			return true;
		}
		if (y < 9 && ocupado[x][y + 1]) {
			return true;
		}
		return false;
	}

	// TODO llamar a esta funcion EN El metodo del movimiento del jugador.
	private static boolean jugarPiedraPapelTijeras() {
		System.out.println("Elige una opción (piedra/papel/tijeras):");
		Random r = new Random();
		Scanner sc = new Scanner(System.in);
		String opcion = sc.nextLine();
		// Generar una respuesta aleatoria para el programa
		String[] opciones = { "piedra", "papel", "tijeras" };
		String opcionPrograma = opciones[r.nextInt(3)];
		// Comprobar quién ha ganado la partida
		if (opcion.equals("piedra")) {
			if (opcionPrograma.equals("piedra")) {
				System.out.println("Empate");
				return false;
			} else if (opcionPrograma.equals("papel")) {
				System.out.println("Has perdido");
				return false;
			} else {
				System.out.println("Has ganado");
				return true;
			}
		} else if (opcion.equals("papel")) {
			if (opcionPrograma.equals("piedra")) {
				System.out.println("Has ganado");
				return true;
			} else if (opcionPrograma.equals("papel")) {
				System.out.println("Empate");
				return false;
			} else {
				System.out.println("Has perdido");
				return false;
			}
		} else {
			if (opcionPrograma.equals("piedra")) {
				System.out.println("Has perdido");
				return false;
			} else if (opcionPrograma.equals("papel")) {
				System.out.println("Has ganado");
				return true;
			} else {
				System.out.println("Empate");
				return false;
			}
		}
	}

	public String toString() {
		String ret = "";

		for (int i = 0; i < board.length; i++) {
			for (int x = 0; x < board.length; x++) {
				if (board[i][x] == null) {
					ret += "x ";

				} else {
					ret += board[i][x] + " ";

				}
			}

			ret += "\n";
		}

		return ret;

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(KeyEvent e) {
		String movimiento = null;
		switch (e.getKeyCode()) {

		case KeyEvent.VK_UP: {
			movimiento = "arriba";
			break;

		}

		case KeyEvent.VK_LEFT: {
			movimiento = "izquierda";
			break;

		}

		case KeyEvent.VK_RIGHT: {
			movimiento = "derecha";
			break;

		}

		default:
			movimiento = "INVALID";
			break;
		}
		moverJugador(x, y, board, movimiento);
	}
}
