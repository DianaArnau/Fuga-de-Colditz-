package prison.project;

import classes.Board;

public class MainPrison {

	public static void main(String[] args) {
		Board board = new Board();
		System.out.println(board);

	}

}
